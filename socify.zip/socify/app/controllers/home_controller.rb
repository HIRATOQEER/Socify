class HomeController < ApplicationController
  def front
  end
end
